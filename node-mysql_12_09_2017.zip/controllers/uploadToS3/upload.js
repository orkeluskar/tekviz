const AWS = require('aws-sdk');

const fs = require('fs');
const zlib = require('zlib');


exports.uploadtoS3 = function(req, res){
    console.log(req.body)
    var body = fs.readFileSync(req.body);

    // Upload the stream
    var s3obj = new AWS.S3({params: {Bucket: 'tweettrendsomkar', Key: 'test12345'}});
    s3obj.upload({Body: body}, function(err, data) {
    if (err) console.log("An error occurred", err);
    console.log("Uploaded the file at", data.Location);
    })
}