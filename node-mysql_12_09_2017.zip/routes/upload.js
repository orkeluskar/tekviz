const router = require('express').Router();
const upload = require('../controllers/uploadToS3/upload');

router.post('/upload', upload.uploadtoS3);

module.exports = router;